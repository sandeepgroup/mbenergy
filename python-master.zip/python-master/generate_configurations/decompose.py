# Reads the given configurations and splits it to monomers, dimers, trimers and tetramers. 
import sys 
import os
import math 
import glob 
from itertools import combinations    # for combinations 

print("Enter the name of input xyz file: ")
print("Available xyz files in current directory: ", glob.glob("*.xyz"))

# reading the file as 2d list and convert string to int or float where required 

tmp=[]
atomcoor=[]
with open(input(),"r") as y:
  natoms = y.readline().split()
  natoms = list(map(int,natoms))
  natoms_mol = y.readline().split()
  natoms_mol = list(map(int,natoms_mol)) 
  for line in y:
    tmp = line.split() 
    atomcoor.append(tmp) 
y.close() 

# check correctness of the input configuration 

if sum(natoms_mol) != len(atomcoor):
  print("total number of atoms not equal to the sum of the total atoms in each fragment ")
  print("Check the input configurations file")
  sys.exit("Exiting .... ") 

# create list for each fragment 

line=0 
fragment=[]
for num in range(len(natoms_mol)):
  tmp=[]
  for atom in range(natoms_mol[num]): 
    tmp.append(atomcoor[line]) 
    line += 1 

  fragment.append(tmp) 

# monomer, dimer, trimer and tetramer -- create dir and files 

if not os.path.exists("mon"):
  os.mkdir("mon")
else:
  print("Warning: directory 'mon' already exists  ") 
if not os.path.exists("dim"):
  os.mkdir("dim")
else:
  print("Warning: directory 'dim' already exists  ") 
if not os.path.exists("tri"):
  os.mkdir("tri")
else:
  print("Warning: directory 'tri' already exists  ") 
if not os.path.exists("tet"):
  os.mkdir("tet")
else:
  print("Warning: directory 'tet' already exists  ") 


# function to write the coordinates into files

def myprint(x, m):
    for i in range(len(x)):
      for j in range(len(x[i])):
        m.write(str(x[i][j]) + " ")
      m.write("\n" ) 

# now split the fragments as needed 
# add "1" to mon, dim, tri and tet so that index starts from 1, not 0 

for mon in range(len(natoms_mol)): 
  with open("mon/%s.xyz" %(mon+1), "w") as f: 
    f.write(str(natoms_mol[mon]) +"\n")  
    f.write("\n") 
    myprint(fragment[mon], f)   
  f.close() 

  for dim in range(mon+1, len(natoms_mol)): 
    with open("dim/%s_%s.xyz" %(mon+1,dim+1), "w") as f: 
      f.write(str(natoms_mol[mon]+natoms_mol[dim]) +"\n")  
      f.write("\n") 
      myprint(fragment[mon], f)   
      myprint(fragment[dim], f)   
    f.close() 

    for tri in range(dim+1, len(natoms_mol)): 
      with open("tri/%s_%s_%s.xyz" %(mon+1,dim+1,tri+1), "w") as f: 
        f.write(str(natoms_mol[mon]+natoms_mol[dim]+natoms_mol[tri]) +"\n")  
        f.write("\n") 
        myprint(fragment[mon], f)   
        myprint(fragment[dim], f)   
        myprint(fragment[tri], f)   
      f.close() 
      
      for tet in range(tri+1, len(natoms_mol)): 
        with open("tet/%s_%s_%s_%s.xyz" %(mon+1,dim+1,tri+1,tet+1), "w") as f: 
          f.write(str(natoms_mol[mon]+natoms_mol[dim]+natoms_mol[tri]+natoms_mol[tet]) +"\n")  
          f.write("\n") 
          myprint(fragment[mon], f)   
          myprint(fragment[dim], f)   
          myprint(fragment[tri], f)   
          myprint(fragment[tet], f)   
        f.close() 

print(  ) 
print("Success  ") 

# for printing statistics -- 

def fac(n,r):
  f = math.factorial
  return f(n) // f(r) // f(n-r) 

print("Statistics  ")  
print("Number of Monomers: ",fac(len(natoms_mol),1))
print("Number of Dimers: ",fac(len(natoms_mol),2))
print("Number of Trimers: ",fac(len(natoms_mol),3))
print("Number of Tetramers: ",fac(len(natoms_mol),4))



