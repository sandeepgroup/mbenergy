*code to generate monomers, dimers, trimers and tetramers for a given configuration.*


