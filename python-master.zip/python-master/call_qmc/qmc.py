import os, sys 
import glob
import json 
from utils import psi4_ener, create_json, sort_numeric

# main program 

newdir="qmc_op"
f_ener="energy.json" 

files = glob.glob("[0-9]*.xyz")
files = sorted(files, key=sort_numeric)

# create a new energy.json file for storing energies 

if not os.path.exists(f_ener):
  create_json(f_ener, files)  

if not os.path.exists(newdir): 
  os.mkdir(newdir)
else:
  print("Warning: directory 'qmc_op' already exits ")

# collect the name of all xyz files and send coordinates to the
# function psi4_ener to calculate energy 

f_ener = open('energy.json',"r+")
Dict_ener = json.load(f_ener) 

for filename in files: 
  trim_name=filename.replace(".xyz","")
  if Dict_ener[trim_name]==0.0:        # do only when energy is not calculated

    with open(filename, 'r') as f:
      f.readline()
      f.readline()
      file_op=("%s/%s.qc" %(newdir,trim_name))
      print("Working on the file %s " %(filename)) 
      E = psi4_ener(f.read(),file_op) 

    f.close()
    Dict_ener[trim_name]=E 

f_ener.seek(0,0)  
f_ener.write(json.dumps(Dict_ener, indent=4))


