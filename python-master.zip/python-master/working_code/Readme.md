*code to generate monomers, dimers, trimers and tetramers for a given configuration.*
*Uses JSON format for storing the data (xyz coordinates and energies) * 



